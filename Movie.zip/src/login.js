function login_check() {
    let pw = document.getElementById("PW").value;
    let id = document.getElementById("ID").value;

    if (id == "") {
      alert("아이디를 입력하세요.");
    }else if (pw == "") {
      alert("비밀번호를 입력하세요.");
    }else{

    }
  }