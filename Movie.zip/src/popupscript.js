function popup(){
    var url = "../free/popup/popup.html";
    var url1 = "../../free/popup/popup.html";
    var name = "popup test";
    var option = "width = 450, height = 330, top = 100, left = 200, location = no"
    window.open(url, name, option);
    
}
function alram(){
    alert('미구현 기능입니다');
}