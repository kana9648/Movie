let num = Math.floor(Math.random() * 5)+1;
let img = document.getElementById(`img`);

img.src = `img/m${num}.jpg`;