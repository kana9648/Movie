function alertwrite(){
    alert('미구현 기능입니다');
}